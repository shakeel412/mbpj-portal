/* ===== MBJP shared script: header, footer, preloader, tracker, dept pages ===== */
const PHONE='0000-0000000'; // TODO: put the real 24/7 ambulance helpline here
const D=[
{k:'health',f:'health.html',t:'شعبہ صحت و علاج',i:'fa-heart-pulse',c:'from-emerald-900 to-teal-600',
 intro:'شعبہ صحت جماعت کے مستحق افراد کو طبی امداد، مفت میڈیکل کیمپس اور علاج معالجے میں معاونت فراہم کرتا ہے۔',
 aims:['مفت میڈیکل کیمپس کا انعقاد','مستحق مریضوں کو ادویات اور علاج میں مدد','ہسپتالوں سے رابطہ اور رہنمائی','صحت سے متعلق آگاہی مہمات'],
 heads:[['شوکت کاتیھوال','ہیڈ شعبہ صحت — کنری ریجن'],['جاوید صدیق مٹھی','ہیڈ شعبہ صحت — کنری ریجن'],['شہزاد قادر','ہیڈ شعبہ صحت — کراچی ریجن']]},
{k:'ambulance',f:'ambulance.html',t:'ایمبولینس سروس 24/7',i:'fa-truck-medical',c:'from-red-800 to-amber-600',
 intro:'جماعت کی ایمبولینس سروس دن رات ہنگامی صورتحال میں مریضوں کو بروقت ہسپتال پہنچانے کے لیے حاضر ہے۔',
 aims:['24 گھنٹے ہنگامی ایمبولینس سہولت','مریضوں کی بروقت منتقلی','میت کی منتقلی میں معاونت','تربیت یافتہ رضاکاروں کی تیاری'],
 heads:[['شکیل سلیم','ہیڈ شعبہ ایمبولینس — کنری ریجن'],['عبدالوکيل نوکوٹ','ہیڈ شعبہ ایمبولینس — کنری ریجن'],['آصف رزاق','ہیڈ شعبہ ایمبولینس — کراچی ریجن']]},
{k:'welfare',f:'welfare.html',t:'شعبہ ویلفیئر و باہمی امداد',i:'fa-hands-holding-heart',c:'from-amber-700 to-emerald-700',
 intro:'شعبہ ویلفیئر راشن، شادی بیاہ اور مشکل حالات میں باہمی امداد کے ذریعے جماعت کے کمزور طبقات کا سہارا بنتا ہے۔',
 aims:['مستحق خاندانوں کو راشن کی فراہمی','شادی و غمی میں معاونت','ہنگامی امداد اور بحالی','خود انحصاری کے منصوبے'],
 heads:[['ارشد صدیق','ہیڈ شعبہ ویلفیئر — کنری ریجن'],['نعیم کمال الدین','ہیڈ شعبہ ویلفیئر — کراچی ریجن']]},
{k:'education',f:'education.html',t:'شعبہ تعلیم و وظائف',i:'fa-graduation-cap',c:'from-emerald-800 to-sky-700',
 intro:'شعبہ تعلیم ہونہار طلبہ کو وظائف، رہنمائی اور تعلیمی سہولیات فراہم کر کے جماعت کا مستقبل روشن کرتا ہے۔',
 aims:['ذہین طلبہ کے لیے وظائف','کتب اور فیس میں معاونت','کیریئر کونسلنگ','تعلیمی سیمینارز'],
 heads:[['سرخالد بھٹی','شعبہ تعلیم — کنری ریجن'],['عبادالرحمن شبیر','ہیڈ شعبہ تعلیم — کراچی ریجن']]},
{k:'sports-youth',f:'sports-youth.html',t:'شعبہ اسپورٹس و یوتھ',i:'fa-futbol',c:'from-emerald-700 to-lime-600',
 intro:'اسپورٹس اور یوتھ شعبہ نوجوانوں کو صحت مند سرگرمیوں، ٹورنامنٹس اور قائدانہ تربیت کے مواقع دیتا ہے۔',
 aims:['کرکٹ و فٹبال ٹورنامنٹس','نوجوانوں کی قیادت کی تربیت','منشیات سے دوری کی مہم','نوجوانوں کے لیے ہنر مندی'],
 heads:[['عابد انور','شعبہ اسپورٹس — کنری ریجن'],['بریرہ سہیل','شعبہ یوتھ — کنری ریجن'],['عدنان جبار','ہیڈ شعبہ اسپورٹس — کراچی ریجن']]},
{k:'media-pr',f:'media-pr.html',t:'شعبہ میڈیا و تعلقات عامہ',i:'fa-bullhorn',c:'from-slate-800 to-emerald-700',
 intro:'شعبہ میڈیا جماعت کی سرگرمیوں کو سوشل میڈیا اور پریس کے ذریعے عوام تک پہنچاتا اور رابطوں کو مضبوط کرتا ہے۔',
 aims:['سرگرمیوں کی کوریج','سوشل میڈیا پیجز کا انتظام','اداروں سے تعلقات','جماعتی اعلانات کی بروقت اشاعت'],
 heads:[['محمد امجد بھٹی','شعبہ میڈیا — کنری ریجن'],['زبیر جبار','ہیڈ شعبہ تعلقات عامہ — کراچی ریجن'],['عبداللہ یوسف','ہیڈ شعبہ میڈیا — کراچی ریجن']]}
];
const logo=s=>`<img src="logo.jpg" alt="logo" class="${s} rounded-full object-cover bg-white" onerror="this.outerHTML='<span class=&quot;${s} rounded-full bg-amber-500 text-emerald-900 flex items-center justify-center font-bold nast&quot;>م</span>'">`;
const card=(n,r,ic)=>`<div class="card bg-white rounded-2xl p-5 text-center shadow" data-aos="fade-up"><div class="ph mx-auto mb-3"><i class="fa-solid ${ic||'fa-user'}"></i></div><h3 class="nast text-emerald-900 text-lg">${n}</h3><p class="text-sm text-slate-600 mt-1">${r}</p></div>`;
const grid=(id,a,ic)=>{document.getElementById(id).innerHTML=a.map(x=>card(x[0],x[1],ic)).join('')};
const apps=()=>JSON.parse(localStorage.getItem('mbjp_apps')||'[]');

/* ---- styles ---- */
document.head.insertAdjacentHTML('beforeend',`<style>
body{font-family:'Noto Sans Arabic',sans-serif;background:#f8fafc}
.nast{font-family:'Noto Nastaliq Urdu',serif;line-height:2.2}
.card{transition:.3s}.card:hover{transform:translateY(-6px) scale(1.03);box-shadow:0 0 25px rgba(245,158,11,.55)}
.ph{width:84px;height:84px;border-radius:50%;background:linear-gradient(135deg,#047857,#f59e0b);color:#fff;display:flex;align-items:center;justify-content:center;font-size:32px;border:3px solid #fde68a}
.glass{background:rgba(6,78,59,.85);backdrop-filter:blur(10px)}
.dd{display:none}.grp:hover .dd{display:block}
#pre{position:fixed;inset:0;background:#064e3b;z-index:100;display:flex;align-items:center;justify-content:center;transition:opacity .6s}
.sp{width:56px;height:56px;border:5px solid #f59e0b;border-top-color:transparent;border-radius:50%;animation:s 1s linear infinite}@keyframes s{to{transform:rotate(360deg)}}
</style>`);

/* ---- preloader ---- */
document.body.insertAdjacentHTML('afterbegin','<div id="pre"><div class="sp"></div></div>');
addEventListener('load',()=>{const p=document.getElementById('pre');p.style.opacity=0;setTimeout(()=>p.remove(),600)});

/* ---- header ---- */
const reg=[['kunri-region.html','کنری ریجن'],['karachi-region.html','کراچی ریجن']];
const li=a=>a.map(x=>`<a href="${x[0]}" class="block px-4 py-2 hover:bg-emerald-50 whitespace-nowrap">${x[1]}</a>`).join('');
const dd=(t,a)=>`<div class="grp relative"><button class="px-3 py-2 hover:text-amber-300">${t} <i class="fa-solid fa-chevron-down text-xs"></i></button><div class="dd absolute right-0 top-full bg-white text-emerald-900 rounded-xl shadow-xl overflow-hidden z-50">${li(a)}</div></div>`;
const depLinks=D.map(d=>[d.f,d.t]);
document.getElementById('hdr').innerHTML=`
<div class="bg-emerald-950 text-amber-200 text-xs md:text-sm py-2 px-4 flex flex-wrap justify-between gap-1"><span><i class="fa-solid fa-location-dot"></i> مرکزی دفتر: مین پبلک پارک روڈ، نیئر اللہ والا چوک، کنری</span><span><i class="fa-solid fa-truck-medical"></i> 24/7 ایمرجنسی ایمبولینس: <b dir="ltr">${PHONE}</b></span></div>
<header class="glass text-white sticky top-0 z-40 shadow-lg"><div class="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
<a href="index.html" class="flex items-center gap-3">${logo('w-12 h-12')}<span class="nast text-sm md:text-lg">مارواڑی بھٹی جماعت پاکستان</span></a>
<nav class="hidden lg:flex items-center gap-1"><a href="index.html" class="px-3 py-2 hover:text-amber-300">مرکزی صفحہ</a>${dd('ریجنز',reg)}${dd('شعبہ جات',depLinks)}<button onclick="MB.track()" class="mr-2 bg-amber-500 hover:bg-amber-600 text-emerald-950 px-4 py-2 rounded-full"><i class="fa-solid fa-magnifying-glass"></i> درخواست ٹریک کریں</button></nav>
<button class="lg:hidden text-2xl" onclick="document.getElementById('mm').classList.toggle('hidden')"><i class="fa-solid fa-bars"></i></button></div>
<div id="mm" class="hidden lg:hidden bg-emerald-950 px-4 pb-3 space-y-1"><a class="block py-1" href="index.html">مرکزی صفحہ</a>${[...reg,...depLinks].map(x=>`<a class="block py-1" href="${x[0]}">${x[1]}</a>`).join('')}<button onclick="MB.track()" class="text-amber-300 py-1">درخواست ٹریک کریں</button></div></header>`;

/* ---- footer + tracker modal + back to top ---- */
document.getElementById('ftr').innerHTML=`
<footer class="bg-emerald-950 text-emerald-100 mt-16 py-10 px-4"><div class="max-w-7xl mx-auto grid md:grid-cols-3 gap-8">
<div class="flex gap-3 items-center">${logo('w-16 h-16')}<div><p class="nast text-amber-300">مارواڑی بھٹی جماعت پاکستان</p><p class="text-sm">دورانیہ 2026 - 2028</p></div></div>
<div class="text-sm space-y-1"><p class="text-amber-300">فوری روابط</p>${[['index.html','مرکزی صفحہ'],...reg,...depLinks].map(x=>`<a class="block hover:text-amber-300" href="${x[0]}">${x[1]}</a>`).join('')}</div>
<div class="text-sm"><p class="text-amber-300">رابطہ</p><p>مین پبلک پارک روڈ، نیئر اللہ والا چوک، کنری</p><p class="mt-2 nast">خدمتِ خلق، اخوت اور خود انحصاری</p></div></div>
<p class="text-center text-xs mt-8 opacity-70">© 2026 مارواڑی بھٹی جماعت پاکستان — جملہ حقوق محفوظ</p></footer>
<div id="tm" class="hidden fixed inset-0 bg-black/60 z-50 items-center justify-center p-4"><div class="bg-white rounded-2xl p-6 w-full max-w-md"><h3 class="nast text-xl text-emerald-900 mb-3">درخواست کی صورتحال</h3>
<input id="tid" dir="ltr" placeholder="MBJP-2026-XXXX" class="w-full border rounded-lg p-3 mb-3"><button onclick="MB.find()" class="w-full bg-emerald-700 text-white rounded-lg py-2">تلاش کریں</button><div id="tr" class="mt-4 text-sm"></div><button onclick="MB.track(0)" class="mt-3 text-slate-500">بند کریں</button></div></div>
<button id="top" onclick="scrollTo({top:0,behavior:'smooth'})" class="hidden fixed bottom-5 left-5 bg-amber-500 text-emerald-950 w-12 h-12 rounded-full shadow-lg z-40"><i class="fa-solid fa-arrow-up"></i></button>`;
addEventListener('scroll',()=>document.getElementById('top').classList.toggle('hidden',scrollY<400));

/* ---- department pages (body data-dept="key") ---- */
function deptPage(d){
 const o=D.find(x=>x.k===d);document.title=o.t+' | MBJP';
 document.getElementById('main').innerHTML=`
 <section class="bg-gradient-to-l ${o.c} text-white py-20 text-center"><i class="fa-solid ${o.i} text-6xl text-amber-300" data-aos="zoom-in"></i><h1 class="nast text-3xl md:text-5xl mt-4" data-aos="fade-up">${o.t}</h1></section>
 <div class="max-w-5xl mx-auto px-4 py-10 space-y-10">
 <section data-aos="fade-up"><h2 class="nast text-2xl text-emerald-900 mb-2">تعارف</h2><p class="leading-loose">${o.intro}</p></section>
 <section data-aos="fade-up"><h2 class="nast text-2xl text-emerald-900 mb-2">اغراض و مقاصد</h2><ul class="space-y-2">${o.aims.map(a=>`<li><i class="fa-solid fa-circle-check text-amber-500 ml-2"></i>${a}</li>`).join('')}</ul></section>
 <section><h2 class="nast text-2xl text-emerald-900 mb-4">شعبے کے ہیڈز</h2><div id="hd" class="grid grid-cols-2 md:grid-cols-3 gap-4"></div></section>
 <section class="bg-white rounded-2xl shadow p-6" data-aos="fade-up"><h2 class="nast text-2xl text-emerald-900 mb-4">آن لائن درخواست فارم</h2>
 <div class="grid md:grid-cols-2 gap-3"><input id="fn" placeholder="مکمل نام" class="border rounded-lg p-3"><input id="fp" dir="ltr" placeholder="03XX-XXXXXXX" class="border rounded-lg p-3"><input id="fc" placeholder="شہر / شاخ" class="border rounded-lg p-3 md:col-span-2"><textarea id="fm" rows="4" placeholder="درخواست کی تفصیل" class="border rounded-lg p-3 md:col-span-2"></textarea></div>
 <button onclick="MB.submit('${o.k}')" class="mt-4 bg-emerald-700 hover:bg-emerald-800 text-white px-8 py-3 rounded-full">درخواست جمع کرائیں</button><div id="fr" class="mt-4"></div></section></div>`;
 grid('hd',o.heads);
}
function submit(k){
 const g=i=>document.getElementById(i).value.trim();
 if(!g('fn')||!g('fp'))return alert('براہ کرم نام اور فون نمبر درج کریں');
 const a=apps();let id;do{id='MBJP-2026-'+(1000+Math.floor(Math.random()*9000))}while(a.some(x=>x.id===id));
 a.push({id,dept:D.find(x=>x.k===k).t,name:g('fn'),phone:g('fp'),city:g('fc'),msg:g('fm'),date:new Date().toLocaleDateString('ur-PK'),status:'موصول — زیرِ جائزہ'});
 localStorage.setItem('mbjp_apps',JSON.stringify(a));
 document.getElementById('fr').innerHTML=`<div class="bg-emerald-50 border border-emerald-300 rounded-xl p-4">آپ کی درخواست جمع ہو گئی۔ ٹریکنگ آئی ڈی: <b dir="ltr" class="text-emerald-800 text-lg">${id}</b></div>`;
}
function track(s=1){const m=document.getElementById('tm');m.classList.toggle('hidden',!s);m.classList.toggle('flex',!!s)}
function find(){
 const v=document.getElementById('tid').value.trim().toUpperCase(),a=apps().find(x=>x.id===v);
 document.getElementById('tr').innerHTML=a?`<div class="bg-emerald-50 rounded-xl p-3 space-y-1"><p>شعبہ: <b>${a.dept}</b></p><p>نام: ${a.name}</p><p>تاریخ: ${a.date}</p><p>حیثیت: <b class="text-amber-600">${a.status}</b></p></div>`:'<p class="text-red-600">یہ آئی ڈی نہیں ملی۔</p>';
}
window.MB={grid,card,submit,track,find};
const dp=document.body.dataset.dept;if(dp)deptPage(dp);
AOS.init({duration:700,once:true});
